/* DUPLICATOR-LITE (PHP BUILD MODE) MYSQL SCRIPT CREATED ON : 2017-11-19 09:15:24 */

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE `aw_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_cptch_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `package_id` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;

CREATE TABLE `aw_cptch_packages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `folder` char(100) NOT NULL,
  `settings` longtext NOT NULL,
  `user_settings` longtext NOT NULL,
  `add_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

CREATE TABLE `aw_cptch_whitelist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` char(31) NOT NULL,
  `ip_from_int` bigint(20) DEFAULT NULL,
  `ip_to_int` bigint(20) DEFAULT NULL,
  `add_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `aw_duplicator_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` mediumblob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

CREATE TABLE `aw_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=371 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

CREATE TABLE `aw_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


/* INSERT TABLE DATA: aw_commentmeta */
INSERT INTO `aw_commentmeta` VALUES("1", "1", "_wp_trash_meta_status", "1");
INSERT INTO `aw_commentmeta` VALUES("2", "1", "_wp_trash_meta_time", "1511037327");

/* INSERT TABLE DATA: aw_comments */
INSERT INTO `aw_comments` VALUES("1", "1", "Автор комментария", "wapuu@wordpress.example", "https://wordpress.org/", "", "2017-11-16 12:37:22", "2017-11-16 09:37:23", "Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com\">Gravatar</a>.", "0", "trash", "", "", "0", "0");

/* INSERT TABLE DATA: aw_cptch_images */
INSERT INTO `aw_cptch_images` VALUES("1", "0.png", "1", "0");
INSERT INTO `aw_cptch_images` VALUES("2", "1.png", "1", "1");
INSERT INTO `aw_cptch_images` VALUES("3", "2.png", "1", "2");
INSERT INTO `aw_cptch_images` VALUES("4", "3.png", "1", "3");
INSERT INTO `aw_cptch_images` VALUES("5", "4.png", "1", "4");
INSERT INTO `aw_cptch_images` VALUES("6", "5.png", "1", "5");
INSERT INTO `aw_cptch_images` VALUES("7", "6.png", "1", "6");
INSERT INTO `aw_cptch_images` VALUES("8", "7.png", "1", "7");
INSERT INTO `aw_cptch_images` VALUES("9", "8.png", "1", "8");
INSERT INTO `aw_cptch_images` VALUES("10", "9.png", "1", "9");
INSERT INTO `aw_cptch_images` VALUES("11", "0.png", "2", "0");
INSERT INTO `aw_cptch_images` VALUES("12", "1.png", "2", "1");
INSERT INTO `aw_cptch_images` VALUES("13", "2.png", "2", "2");
INSERT INTO `aw_cptch_images` VALUES("14", "3.png", "2", "3");
INSERT INTO `aw_cptch_images` VALUES("15", "4.png", "2", "4");
INSERT INTO `aw_cptch_images` VALUES("16", "5.png", "2", "5");
INSERT INTO `aw_cptch_images` VALUES("17", "6.png", "2", "6");
INSERT INTO `aw_cptch_images` VALUES("18", "7.png", "2", "7");
INSERT INTO `aw_cptch_images` VALUES("19", "8.png", "2", "8");
INSERT INTO `aw_cptch_images` VALUES("20", "9.png", "2", "9");
INSERT INTO `aw_cptch_images` VALUES("21", "0.png", "3", "0");
INSERT INTO `aw_cptch_images` VALUES("22", "1.png", "3", "1");
INSERT INTO `aw_cptch_images` VALUES("23", "2.png", "3", "2");
INSERT INTO `aw_cptch_images` VALUES("24", "3.png", "3", "3");
INSERT INTO `aw_cptch_images` VALUES("25", "4.png", "3", "4");
INSERT INTO `aw_cptch_images` VALUES("26", "5.png", "3", "5");
INSERT INTO `aw_cptch_images` VALUES("27", "6.png", "3", "6");
INSERT INTO `aw_cptch_images` VALUES("28", "7.png", "3", "7");
INSERT INTO `aw_cptch_images` VALUES("29", "8.png", "3", "8");
INSERT INTO `aw_cptch_images` VALUES("30", "9.png", "3", "9");
INSERT INTO `aw_cptch_images` VALUES("31", "0.png", "4", "0");
INSERT INTO `aw_cptch_images` VALUES("32", "1.png", "4", "1");
INSERT INTO `aw_cptch_images` VALUES("33", "2.png", "4", "2");
INSERT INTO `aw_cptch_images` VALUES("34", "3.png", "4", "3");
INSERT INTO `aw_cptch_images` VALUES("35", "4.png", "4", "4");
INSERT INTO `aw_cptch_images` VALUES("36", "5.png", "4", "5");
INSERT INTO `aw_cptch_images` VALUES("37", "6.png", "4", "6");
INSERT INTO `aw_cptch_images` VALUES("38", "7.png", "4", "7");
INSERT INTO `aw_cptch_images` VALUES("39", "8.png", "4", "8");
INSERT INTO `aw_cptch_images` VALUES("40", "9.png", "4", "9");
INSERT INTO `aw_cptch_images` VALUES("41", "1.png", "5", "1");
INSERT INTO `aw_cptch_images` VALUES("42", "2.png", "5", "2");
INSERT INTO `aw_cptch_images` VALUES("43", "3.png", "5", "3");
INSERT INTO `aw_cptch_images` VALUES("44", "4.png", "5", "4");
INSERT INTO `aw_cptch_images` VALUES("45", "5.png", "5", "5");
INSERT INTO `aw_cptch_images` VALUES("46", "6.png", "5", "6");
INSERT INTO `aw_cptch_images` VALUES("47", "7.png", "5", "7");
INSERT INTO `aw_cptch_images` VALUES("48", "8.png", "5", "8");
INSERT INTO `aw_cptch_images` VALUES("49", "9.png", "5", "9");
INSERT INTO `aw_cptch_images` VALUES("50", "1.png", "6", "1");
INSERT INTO `aw_cptch_images` VALUES("51", "2.png", "6", "2");
INSERT INTO `aw_cptch_images` VALUES("52", "3.png", "6", "3");
INSERT INTO `aw_cptch_images` VALUES("53", "4.png", "6", "4");
INSERT INTO `aw_cptch_images` VALUES("54", "5.png", "6", "5");
INSERT INTO `aw_cptch_images` VALUES("55", "6.png", "6", "6");
INSERT INTO `aw_cptch_images` VALUES("56", "7.png", "6", "7");
INSERT INTO `aw_cptch_images` VALUES("57", "8.png", "6", "8");
INSERT INTO `aw_cptch_images` VALUES("58", "9.png", "6", "9");
INSERT INTO `aw_cptch_images` VALUES("59", "1.png", "7", "1");
INSERT INTO `aw_cptch_images` VALUES("60", "2.png", "7", "2");
INSERT INTO `aw_cptch_images` VALUES("61", "3.png", "7", "3");
INSERT INTO `aw_cptch_images` VALUES("62", "4.png", "7", "4");
INSERT INTO `aw_cptch_images` VALUES("63", "5.png", "7", "5");
INSERT INTO `aw_cptch_images` VALUES("64", "6.png", "7", "6");
INSERT INTO `aw_cptch_images` VALUES("65", "7.png", "7", "7");
INSERT INTO `aw_cptch_images` VALUES("66", "8.png", "7", "8");
INSERT INTO `aw_cptch_images` VALUES("67", "9.png", "7", "9");
INSERT INTO `aw_cptch_images` VALUES("68", "1.png", "8", "1");
INSERT INTO `aw_cptch_images` VALUES("69", "2.png", "8", "2");
INSERT INTO `aw_cptch_images` VALUES("70", "3.png", "8", "3");
INSERT INTO `aw_cptch_images` VALUES("71", "4.png", "8", "4");
INSERT INTO `aw_cptch_images` VALUES("72", "5.png", "8", "5");
INSERT INTO `aw_cptch_images` VALUES("73", "6.png", "8", "6");
INSERT INTO `aw_cptch_images` VALUES("74", "7.png", "8", "7");
INSERT INTO `aw_cptch_images` VALUES("75", "8.png", "8", "8");
INSERT INTO `aw_cptch_images` VALUES("76", "9.png", "8", "9");
INSERT INTO `aw_cptch_images` VALUES("77", "1.png", "9", "1");
INSERT INTO `aw_cptch_images` VALUES("78", "2.png", "9", "2");
INSERT INTO `aw_cptch_images` VALUES("79", "3.png", "9", "3");
INSERT INTO `aw_cptch_images` VALUES("80", "4.png", "9", "4");
INSERT INTO `aw_cptch_images` VALUES("81", "5.png", "9", "5");
INSERT INTO `aw_cptch_images` VALUES("82", "6.png", "9", "6");
INSERT INTO `aw_cptch_images` VALUES("83", "7.png", "9", "7");
INSERT INTO `aw_cptch_images` VALUES("84", "8.png", "9", "8");
INSERT INTO `aw_cptch_images` VALUES("85", "9.png", "9", "9");
INSERT INTO `aw_cptch_images` VALUES("86", "1.png", "10", "1");
INSERT INTO `aw_cptch_images` VALUES("87", "2.png", "10", "2");
INSERT INTO `aw_cptch_images` VALUES("88", "3.png", "10", "3");
INSERT INTO `aw_cptch_images` VALUES("89", "4.png", "10", "4");
INSERT INTO `aw_cptch_images` VALUES("90", "5.png", "10", "5");
INSERT INTO `aw_cptch_images` VALUES("91", "6.png", "10", "6");
INSERT INTO `aw_cptch_images` VALUES("92", "7.png", "10", "7");
INSERT INTO `aw_cptch_images` VALUES("93", "8.png", "10", "8");
INSERT INTO `aw_cptch_images` VALUES("94", "9.png", "10", "9");
INSERT INTO `aw_cptch_images` VALUES("95", "1.png", "11", "1");
INSERT INTO `aw_cptch_images` VALUES("96", "2.png", "11", "2");
INSERT INTO `aw_cptch_images` VALUES("97", "3.png", "11", "3");
INSERT INTO `aw_cptch_images` VALUES("98", "4.png", "11", "4");
INSERT INTO `aw_cptch_images` VALUES("99", "5.png", "11", "5");
INSERT INTO `aw_cptch_images` VALUES("100", "6.png", "11", "6");
INSERT INTO `aw_cptch_images` VALUES("101", "7.png", "11", "7");
INSERT INTO `aw_cptch_images` VALUES("102", "8.png", "11", "8");
INSERT INTO `aw_cptch_images` VALUES("103", "9.png", "11", "9");
INSERT INTO `aw_cptch_images` VALUES("104", "1.png", "12", "1");
INSERT INTO `aw_cptch_images` VALUES("105", "2.png", "12", "2");
INSERT INTO `aw_cptch_images` VALUES("106", "3.png", "12", "3");
INSERT INTO `aw_cptch_images` VALUES("107", "4.png", "12", "4");
INSERT INTO `aw_cptch_images` VALUES("108", "5.png", "12", "5");
INSERT INTO `aw_cptch_images` VALUES("109", "6.png", "12", "6");
INSERT INTO `aw_cptch_images` VALUES("110", "7.png", "12", "7");
INSERT INTO `aw_cptch_images` VALUES("111", "8.png", "12", "8");
INSERT INTO `aw_cptch_images` VALUES("112", "9.png", "12", "9");

/* INSERT TABLE DATA: aw_cptch_packages */
INSERT INTO `aw_cptch_packages` VALUES("1", "Arabic ( black numbers - transparent background )", "arabic_bt", "", "", "2017-11-18 21:30:55");
INSERT INTO `aw_cptch_packages` VALUES("2", "Arabic ( black numbers - white background )", "arabic_bw", "", "", "2017-11-18 21:30:55");
INSERT INTO `aw_cptch_packages` VALUES("3", "Arabic ( white numbers - transparent background )", "arabic_wt", "", "", "2017-11-18 21:30:55");
INSERT INTO `aw_cptch_packages` VALUES("4", "Arabic ( white numbers - black background )", "arabic_wb", "", "", "2017-11-18 21:30:55");
INSERT INTO `aw_cptch_packages` VALUES("5", "Dots ( black dots - transparent background )", "dots_bt", "", "", "2017-11-18 21:30:55");
INSERT INTO `aw_cptch_packages` VALUES("6", "Dots ( black dots - white background )", "dots_bw", "", "", "2017-11-18 21:30:55");
INSERT INTO `aw_cptch_packages` VALUES("7", "Dots ( white dots - black background )", "dots_wb", "", "", "2017-11-18 21:30:55");
INSERT INTO `aw_cptch_packages` VALUES("8", "Dots ( white dots - transparent background )", "dots_wt", "", "", "2017-11-18 21:30:55");
INSERT INTO `aw_cptch_packages` VALUES("9", "Roman ( black numbers - transparent background )", "roman_bt", "", "", "2017-11-18 21:30:55");
INSERT INTO `aw_cptch_packages` VALUES("10", "Roman ( black numbers - white background )", "roman_bw", "", "", "2017-11-18 21:30:55");
INSERT INTO `aw_cptch_packages` VALUES("11", "Roman ( white numbers - black background )", "roman_wb", "", "", "2017-11-18 21:30:55");
INSERT INTO `aw_cptch_packages` VALUES("12", "Roman ( white numbers - transparent background )", "roman_wt", "", "", "2017-11-18 21:30:55");

/* INSERT TABLE DATA: aw_duplicator_packages */
INSERT INTO `aw_duplicator_packages` VALUES("1", "20171119_fotoprirody", "f6f0dc80908b52918306171119073200", "100", "2017-11-19 07:32:33", "Admin", "O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2017-11-19 07:32:00\";s:7:\"Version\";s:6:\"1.2.30\";s:9:\"VersionWP\";s:3:\"4.9\";s:9:\"VersionDB\";s:6:\"5.6.37\";s:10:\"VersionPHP\";s:6:\"7.0.21\";s:9:\"VersionOS\";s:5:\"WINNT\";s:2:\"ID\";i:1;s:4:\"Name\";s:20:\"20171119_fotoprirody\";s:4:\"Hash\";s:32:\"f6f0dc80908b52918306171119073200\";s:8:\"NameHash\";s:53:\"20171119_fotoprirody_f6f0dc80908b52918306171119073200\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:40:\"C:/OSPanel/domains/test/wp-snapshots/tmp\";s:8:\"StoreURL\";s:25:\"http://test/wp-snapshots/\";s:8:\"ScanFile\";s:63:\"20171119_fotoprirody_f6f0dc80908b52918306171119073200_scan.json\";s:7:\"Runtime\";s:10:\"68.24 sec.\";s:7:\"ExeSize\";s:8:\"443.29KB\";s:7:\"ZipSize\";s:6:\"19.4MB\";s:6:\"Status\";N;s:6:\"WPUser\";s:5:\"Admin\";s:7:\"Archive\";O:11:\"DUP_Archive\":18:{s:10:\"FilterDirs\";s:0:\"\";s:11:\"FilterFiles\";s:0:\"\";s:10:\"FilterExts\";s:0:\"\";s:13:\"FilterDirsAll\";a:0:{}s:14:\"FilterFilesAll\";a:0:{}s:13:\"FilterExtsAll\";a:0:{}s:8:\"FilterOn\";i:0;s:12:\"ExportOnlyDB\";i:0;s:4:\"File\";s:65:\"20171119_fotoprirody_f6f0dc80908b52918306171119073200_archive.zip\";s:6:\"Format\";s:3:\"ZIP\";s:7:\"PackDir\";s:23:\"C:/OSPanel/domains/test\";s:4:\"Size\";i:20343925;s:4:\"Dirs\";a:0:{}s:5:\"Files\";a:0:{}s:10:\"FilterInfo\";O:23:\"DUP_Archive_Filter_Info\":8:{s:4:\"Dirs\";O:34:\"DUP_Archive_Filter_Scope_Directory\":4:{s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:5:\"Files\";O:29:\"DUP_Archive_Filter_Scope_File\":5:{s:4:\"Size\";a:0:{}s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:4:\"Exts\";O:29:\"DUP_Archive_Filter_Scope_Base\":2:{s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:9:\"UDirCount\";i:0;s:10:\"UFileCount\";i:0;s:9:\"UExtCount\";i:0;s:8:\"TreeSize\";a:0:{}s:11:\"TreeWarning\";a:0:{}}s:10:\"\0*\0Package\";r:1;s:29:\"\0DUP_Archive\0tmpFilterDirsAll\";a:0:{}s:24:\"\0DUP_Archive\0wpCorePaths\";a:6:{i:0;s:32:\"C:/OSPanel/domains/test/wp-admin\";i:1;s:42:\"C:/OSPanel/domains/test/wp-content/uploads\";i:2;s:44:\"C:/OSPanel/domains/test/wp-content/languages\";i:3;s:42:\"C:/OSPanel/domains/test/wp-content/plugins\";i:4;s:41:\"C:/OSPanel/domains/test/wp-content/themes\";i:5;s:35:\"C:/OSPanel/domains/test/wp-includes\";}}s:9:\"Installer\";O:13:\"DUP_Installer\":7:{s:4:\"File\";s:67:\"20171119_fotoprirody_f6f0dc80908b52918306171119073200_installer.php\";s:4:\"Size\";i:453934;s:10:\"OptsDBHost\";s:0:\"\";s:10:\"OptsDBPort\";s:0:\"\";s:10:\"OptsDBName\";s:0:\"\";s:10:\"OptsDBUser\";s:0:\"\";s:10:\"\0*\0Package\";r:1;}s:8:\"Database\";O:12:\"DUP_Database\":13:{s:4:\"Type\";s:5:\"MySQL\";s:4:\"Size\";i:119390;s:4:\"File\";s:66:\"20171119_fotoprirody_f6f0dc80908b52918306171119073200_database.sql\";s:4:\"Path\";N;s:12:\"FilterTables\";s:0:\"\";s:8:\"FilterOn\";i:0;s:4:\"Name\";N;s:10:\"Compatible\";s:0:\"\";s:8:\"Comments\";s:28:\"MySQL Community Server (GPL)\";s:10:\"\0*\0Package\";r:1;s:25:\"\0DUP_Database\0dbStorePath\";s:107:\"C:/OSPanel/domains/test/wp-snapshots/tmp/20171119_fotoprirody_f6f0dc80908b52918306171119073200_database.sql\";s:23:\"\0DUP_Database\0EOFMarker\";s:0:\"\";s:26:\"\0DUP_Database\0networkFlush\";b:0;}}");
INSERT INTO `aw_duplicator_packages` VALUES("2", "20171119_fotoprirody", "78536bc7ae89d2de2923171119091509", "20", "2017-11-19 09:15:24", "Admin", "O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2017-11-19 09:15:09\";s:7:\"Version\";s:6:\"1.2.30\";s:9:\"VersionWP\";s:3:\"4.9\";s:9:\"VersionDB\";s:6:\"5.6.37\";s:10:\"VersionPHP\";s:6:\"7.0.21\";s:9:\"VersionOS\";s:5:\"WINNT\";s:2:\"ID\";i:2;s:4:\"Name\";s:20:\"20171119_fotoprirody\";s:4:\"Hash\";s:32:\"78536bc7ae89d2de2923171119091509\";s:8:\"NameHash\";s:53:\"20171119_fotoprirody_78536bc7ae89d2de2923171119091509\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:40:\"C:/OSPanel/domains/test/wp-snapshots/tmp\";s:8:\"StoreURL\";s:25:\"http://test/wp-snapshots/\";s:8:\"ScanFile\";s:63:\"20171119_fotoprirody_78536bc7ae89d2de2923171119091509_scan.json\";s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";s:5:\"Admin\";s:7:\"Archive\";O:11:\"DUP_Archive\":18:{s:10:\"FilterDirs\";s:0:\"\";s:11:\"FilterFiles\";s:0:\"\";s:10:\"FilterExts\";s:0:\"\";s:13:\"FilterDirsAll\";a:0:{}s:14:\"FilterFilesAll\";a:0:{}s:13:\"FilterExtsAll\";a:0:{}s:8:\"FilterOn\";i:0;s:12:\"ExportOnlyDB\";i:0;s:4:\"File\";s:65:\"20171119_fotoprirody_78536bc7ae89d2de2923171119091509_archive.zip\";s:6:\"Format\";s:3:\"ZIP\";s:7:\"PackDir\";s:23:\"C:/OSPanel/domains/test\";s:4:\"Size\";i:0;s:4:\"Dirs\";a:0:{}s:5:\"Files\";a:0:{}s:10:\"FilterInfo\";O:23:\"DUP_Archive_Filter_Info\":8:{s:4:\"Dirs\";O:34:\"DUP_Archive_Filter_Scope_Directory\":4:{s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:5:\"Files\";O:29:\"DUP_Archive_Filter_Scope_File\":5:{s:4:\"Size\";a:0:{}s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:4:\"Exts\";O:29:\"DUP_Archive_Filter_Scope_Base\":2:{s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:9:\"UDirCount\";i:0;s:10:\"UFileCount\";i:0;s:9:\"UExtCount\";i:0;s:8:\"TreeSize\";a:0:{}s:11:\"TreeWarning\";a:0:{}}s:10:\"\0*\0Package\";O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2017-11-19 09:15:09\";s:7:\"Version\";s:6:\"1.2.30\";s:9:\"VersionWP\";s:3:\"4.9\";s:9:\"VersionDB\";s:6:\"5.6.37\";s:10:\"VersionPHP\";s:6:\"7.0.21\";s:9:\"VersionOS\";s:5:\"WINNT\";s:2:\"ID\";N;s:4:\"Name\";s:20:\"20171119_fotoprirody\";s:4:\"Hash\";s:32:\"78536bc7ae89d2de2923171119091509\";s:8:\"NameHash\";s:53:\"20171119_fotoprirody_78536bc7ae89d2de2923171119091509\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:40:\"C:/OSPanel/domains/test/wp-snapshots/tmp\";s:8:\"StoreURL\";s:25:\"http://test/wp-snapshots/\";s:8:\"ScanFile\";N;s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";N;s:7:\"Archive\";r:22;s:9:\"Installer\";O:13:\"DUP_Installer\":7:{s:4:\"File\";s:67:\"20171119_fotoprirody_78536bc7ae89d2de2923171119091509_installer.php\";s:4:\"Size\";i:0;s:10:\"OptsDBHost\";s:0:\"\";s:10:\"OptsDBPort\";s:0:\"\";s:10:\"OptsDBName\";s:0:\"\";s:10:\"OptsDBUser\";s:0:\"\";s:10:\"\0*\0Package\";r:57;}s:8:\"Database\";O:12:\"DUP_Database\":13:{s:4:\"Type\";s:5:\"MySQL\";s:4:\"Size\";N;s:4:\"File\";s:66:\"20171119_fotoprirody_78536bc7ae89d2de2923171119091509_database.sql\";s:4:\"Path\";N;s:12:\"FilterTables\";s:0:\"\";s:8:\"FilterOn\";i:0;s:4:\"Name\";N;s:10:\"Compatible\";s:0:\"\";s:8:\"Comments\";s:28:\"MySQL Community Server (GPL)\";s:10:\"\0*\0Package\";r:1;s:25:\"\0DUP_Database\0dbStorePath\";N;s:23:\"\0DUP_Database\0EOFMarker\";s:0:\"\";s:26:\"\0DUP_Database\0networkFlush\";b:0;}}s:29:\"\0DUP_Archive\0tmpFilterDirsAll\";a:0:{}s:24:\"\0DUP_Archive\0wpCorePaths\";a:6:{i:0;s:32:\"C:/OSPanel/domains/test/wp-admin\";i:1;s:42:\"C:/OSPanel/domains/test/wp-content/uploads\";i:2;s:44:\"C:/OSPanel/domains/test/wp-content/languages\";i:3;s:42:\"C:/OSPanel/domains/test/wp-content/plugins\";i:4;s:41:\"C:/OSPanel/domains/test/wp-content/themes\";i:5;s:35:\"C:/OSPanel/domains/test/wp-includes\";}}s:9:\"Installer\";r:79;s:8:\"Database\";r:87;}");

/* INSERT TABLE DATA: aw_options */
INSERT INTO `aw_options` VALUES("1", "siteurl", "http://test", "yes");
INSERT INTO `aw_options` VALUES("2", "home", "http://test", "yes");
INSERT INTO `aw_options` VALUES("3", "blogname", "Фото природы", "yes");
INSERT INTO `aw_options` VALUES("4", "blogdescription", "", "yes");
INSERT INTO `aw_options` VALUES("5", "users_can_register", "0", "yes");
INSERT INTO `aw_options` VALUES("6", "admin_email", "kosadaka98@mail.ru", "yes");
INSERT INTO `aw_options` VALUES("7", "start_of_week", "1", "yes");
INSERT INTO `aw_options` VALUES("8", "use_balanceTags", "0", "yes");
INSERT INTO `aw_options` VALUES("9", "use_smilies", "1", "yes");
INSERT INTO `aw_options` VALUES("10", "require_name_email", "1", "yes");
INSERT INTO `aw_options` VALUES("11", "comments_notify", "1", "yes");
INSERT INTO `aw_options` VALUES("12", "posts_per_rss", "10", "yes");
INSERT INTO `aw_options` VALUES("13", "rss_use_excerpt", "0", "yes");
INSERT INTO `aw_options` VALUES("14", "mailserver_url", "mail.example.com", "yes");
INSERT INTO `aw_options` VALUES("15", "mailserver_login", "login@example.com", "yes");
INSERT INTO `aw_options` VALUES("16", "mailserver_pass", "password", "yes");
INSERT INTO `aw_options` VALUES("17", "mailserver_port", "110", "yes");
INSERT INTO `aw_options` VALUES("18", "default_category", "1", "yes");
INSERT INTO `aw_options` VALUES("19", "default_comment_status", "open", "yes");
INSERT INTO `aw_options` VALUES("20", "default_ping_status", "open", "yes");
INSERT INTO `aw_options` VALUES("21", "default_pingback_flag", "0", "yes");
INSERT INTO `aw_options` VALUES("22", "posts_per_page", "10", "yes");
INSERT INTO `aw_options` VALUES("23", "date_format", "d.m.Y", "yes");
INSERT INTO `aw_options` VALUES("24", "time_format", "H:i", "yes");
INSERT INTO `aw_options` VALUES("25", "links_updated_date_format", "d.m.Y H:i", "yes");
INSERT INTO `aw_options` VALUES("26", "comment_moderation", "0", "yes");
INSERT INTO `aw_options` VALUES("27", "moderation_notify", "1", "yes");
INSERT INTO `aw_options` VALUES("28", "permalink_structure", "/%year%/%monthnum%/%day%/%postname%/", "yes");
INSERT INTO `aw_options` VALUES("29", "rewrite_rules", "a:90:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}", "yes");
INSERT INTO `aw_options` VALUES("30", "hack_file", "0", "yes");
INSERT INTO `aw_options` VALUES("31", "blog_charset", "UTF-8", "yes");
INSERT INTO `aw_options` VALUES("32", "moderation_keys", "", "no");
INSERT INTO `aw_options` VALUES("33", "active_plugins", "a:5:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:19:\"captcha/captcha.php\";i:2;s:25:\"duplicator/duplicator.php\";i:3;s:39:\"platinum-seo-pack/platinum_seo_pack.php\";i:4;s:23:\"rustolat/rus-to-lat.php\";}", "yes");
INSERT INTO `aw_options` VALUES("34", "category_base", "", "yes");
INSERT INTO `aw_options` VALUES("35", "ping_sites", "http://rpc.pingomatic.com/", "yes");
INSERT INTO `aw_options` VALUES("36", "comment_max_links", "2", "yes");
INSERT INTO `aw_options` VALUES("37", "gmt_offset", "3", "yes");
INSERT INTO `aw_options` VALUES("38", "default_email_category", "1", "yes");
INSERT INTO `aw_options` VALUES("39", "recently_edited", "a:2:{i:0;s:61:\"C:\\OSPanel\\domains\\test/wp-content/themes/semicolon/style.css\";i:2;s:0:\"\";}", "no");
INSERT INTO `aw_options` VALUES("40", "template", "twentyfifteen", "yes");
INSERT INTO `aw_options` VALUES("41", "stylesheet", "twentyfifteen", "yes");
INSERT INTO `aw_options` VALUES("42", "comment_whitelist", "1", "yes");
INSERT INTO `aw_options` VALUES("43", "blacklist_keys", "", "no");
INSERT INTO `aw_options` VALUES("44", "comment_registration", "0", "yes");
INSERT INTO `aw_options` VALUES("45", "html_type", "text/html", "yes");
INSERT INTO `aw_options` VALUES("46", "use_trackback", "0", "yes");
INSERT INTO `aw_options` VALUES("47", "default_role", "subscriber", "yes");
INSERT INTO `aw_options` VALUES("48", "db_version", "38590", "yes");
INSERT INTO `aw_options` VALUES("49", "uploads_use_yearmonth_folders", "1", "yes");
INSERT INTO `aw_options` VALUES("50", "upload_path", "", "yes");
INSERT INTO `aw_options` VALUES("51", "blog_public", "0", "yes");
INSERT INTO `aw_options` VALUES("52", "default_link_category", "2", "yes");
INSERT INTO `aw_options` VALUES("53", "show_on_front", "posts", "yes");
INSERT INTO `aw_options` VALUES("54", "tag_base", "", "yes");
INSERT INTO `aw_options` VALUES("55", "show_avatars", "1", "yes");
INSERT INTO `aw_options` VALUES("56", "avatar_rating", "G", "yes");
INSERT INTO `aw_options` VALUES("57", "upload_url_path", "", "yes");
INSERT INTO `aw_options` VALUES("58", "thumbnail_size_w", "150", "yes");
INSERT INTO `aw_options` VALUES("59", "thumbnail_size_h", "150", "yes");
INSERT INTO `aw_options` VALUES("60", "thumbnail_crop", "1", "yes");
INSERT INTO `aw_options` VALUES("61", "medium_size_w", "300", "yes");
INSERT INTO `aw_options` VALUES("62", "medium_size_h", "300", "yes");
INSERT INTO `aw_options` VALUES("63", "avatar_default", "mystery", "yes");
INSERT INTO `aw_options` VALUES("64", "large_size_w", "1024", "yes");
INSERT INTO `aw_options` VALUES("65", "large_size_h", "1024", "yes");
INSERT INTO `aw_options` VALUES("66", "image_default_link_type", "none", "yes");
INSERT INTO `aw_options` VALUES("67", "image_default_size", "", "yes");
INSERT INTO `aw_options` VALUES("68", "image_default_align", "", "yes");
INSERT INTO `aw_options` VALUES("69", "close_comments_for_old_posts", "0", "yes");
INSERT INTO `aw_options` VALUES("70", "close_comments_days_old", "14", "yes");
INSERT INTO `aw_options` VALUES("71", "thread_comments", "1", "yes");
INSERT INTO `aw_options` VALUES("72", "thread_comments_depth", "5", "yes");
INSERT INTO `aw_options` VALUES("73", "page_comments", "0", "yes");
INSERT INTO `aw_options` VALUES("74", "comments_per_page", "50", "yes");
INSERT INTO `aw_options` VALUES("75", "default_comments_page", "newest", "yes");
INSERT INTO `aw_options` VALUES("76", "comment_order", "asc", "yes");
INSERT INTO `aw_options` VALUES("77", "sticky_posts", "a:0:{}", "yes");
INSERT INTO `aw_options` VALUES("78", "widget_categories", "a:2:{i:2;a:4:{s:5:\"title\";s:14:\"Рубрики\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("79", "widget_text", "a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("80", "widget_rss", "a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("81", "uninstall_plugins", "a:1:{s:19:\"captcha/captcha.php\";s:20:\"cptch_delete_options\";}", "no");
INSERT INTO `aw_options` VALUES("82", "timezone_string", "", "yes");
INSERT INTO `aw_options` VALUES("83", "page_for_posts", "0", "yes");
INSERT INTO `aw_options` VALUES("84", "page_on_front", "0", "yes");
INSERT INTO `aw_options` VALUES("85", "default_post_format", "0", "yes");
INSERT INTO `aw_options` VALUES("86", "link_manager_enabled", "0", "yes");
INSERT INTO `aw_options` VALUES("87", "finished_splitting_shared_terms", "1", "yes");
INSERT INTO `aw_options` VALUES("88", "site_icon", "0", "yes");
INSERT INTO `aw_options` VALUES("89", "medium_large_size_w", "768", "yes");
INSERT INTO `aw_options` VALUES("90", "medium_large_size_h", "0", "yes");
INSERT INTO `aw_options` VALUES("91", "initial_db_version", "38590", "yes");
INSERT INTO `aw_options` VALUES("92", "aw_user_roles", "a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}", "yes");
INSERT INTO `aw_options` VALUES("93", "fresh_site", "0", "yes");
INSERT INTO `aw_options` VALUES("94", "WPLANG", "ru_RU", "yes");
INSERT INTO `aw_options` VALUES("95", "widget_search", "a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("96", "widget_recent-posts", "a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("97", "widget_recent-comments", "a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:3;}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("98", "widget_archives", "a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("99", "widget_meta", "a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("100", "sidebars_widgets", "a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:7:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:10:\"nav_menu-2\";}s:13:\"array_version\";i:3;}", "yes");
INSERT INTO `aw_options` VALUES("101", "widget_pages", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("102", "widget_calendar", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("103", "widget_media_audio", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("104", "widget_media_image", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("105", "widget_media_video", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("106", "widget_tag_cloud", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("107", "widget_nav_menu", "a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("108", "widget_custom_html", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("109", "cron", "a:6:{i:1511083684;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1511084245;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1511084301;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1511116084;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1511159359;a:1:{s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}", "yes");
INSERT INTO `aw_options` VALUES("110", "theme_mods_twentyseventeen", "a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1511020552;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}", "yes");
INSERT INTO `aw_options` VALUES("125", "_site_transient_timeout_browser_d7d4c74f0a674f89740d500516dd9302", "1511429869", "no");
INSERT INTO `aw_options` VALUES("126", "_site_transient_browser_d7d4c74f0a674f89740d500516dd9302", "a:10:{s:4:\"name\";s:5:\"Opera\";s:7:\"version\";s:5:\"12.11\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:22:\"https://www.opera.com/\";s:7:\"img_src\";s:42:\"http://s.w.org/images/browsers/opera.png?1\";s:11:\"img_src_ssl\";s:43:\"https://s.w.org/images/browsers/opera.png?1\";s:15:\"current_version\";s:5:\"12.18\";s:7:\"upgrade\";b:1;s:8:\"insecure\";b:1;s:6:\"mobile\";b:0;}", "no");
INSERT INTO `aw_options` VALUES("127", "can_compress_scripts", "1", "no");
INSERT INTO `aw_options` VALUES("145", "recently_activated", "a:1:{s:19:\"akismet/akismet.php\";i:1511029605;}", "yes");
INSERT INTO `aw_options` VALUES("159", "widget_media_gallery", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("176", "new_admin_email", "kosadaka98@mail.ru", "yes");
INSERT INTO `aw_options` VALUES("210", "current_theme", "Twenty Fifteen", "yes");
INSERT INTO `aw_options` VALUES("211", "theme_mods_twentysixteen", "a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1511020596;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}", "yes");
INSERT INTO `aw_options` VALUES("212", "theme_switched", "", "yes");
INSERT INTO `aw_options` VALUES("213", "_transient_twentysixteen_categories", "1", "yes");
INSERT INTO `aw_options` VALUES("215", "theme_mods_twentyfifteen", "a:9:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"background_color\";s:6:\"000000\";s:16:\"background_image\";s:54:\"http://test/wp-content/uploads/2017/11/GN6KUHBqlIg.jpg\";s:17:\"sidebar_textcolor\";s:7:\"#2a892f\";s:23:\"header_background_color\";s:7:\"#141004\";s:21:\"background_position_x\";s:4:\"left\";s:21:\"background_position_y\";s:3:\"top\";}", "yes");
INSERT INTO `aw_options` VALUES("221", "theme_mods_semicolon", "a:12:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"background_image\";s:54:\"http://test/wp-content/uploads/2017/11/GN6KUHBqlIg.jpg\";s:21:\"background_position_x\";s:6:\"center\";s:21:\"background_position_y\";s:3:\"top\";s:17:\"background_preset\";s:4:\"fill\";s:15:\"background_size\";s:5:\"cover\";s:17:\"background_repeat\";s:9:\"no-repeat\";s:21:\"background_attachment\";s:5:\"fixed\";s:16:\"background_color\";s:6:\"191919\";s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1511035804;s:4:\"data\";a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}s:14:\"footer-sidebar\";a:0:{}}}}", "yes");
INSERT INTO `aw_options` VALUES("225", "_transient_timeout_plugin_slugs", "1511162981", "no");
INSERT INTO `aw_options` VALUES("226", "_transient_plugin_slugs", "a:7:{i:0;s:19:\"akismet/akismet.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:19:\"captcha/captcha.php\";i:3;s:25:\"duplicator/duplicator.php\";i:4;s:9:\"hello.php\";i:5;s:39:\"platinum-seo-pack/platinum_seo_pack.php\";i:6;s:23:\"rustolat/rus-to-lat.php\";}", "no");
INSERT INTO `aw_options` VALUES("229", "widget_akismet_widget", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("236", "aiowpsec_db_version", "1.9", "yes");
INSERT INTO `aw_options` VALUES("237", "aio_wp_security_configs", "a:83:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:18:\"kosadaka98@mail.ru\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"h2piv7wbkreohdzy34sx\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"fkl0wum0ijjbormpf1jj\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:0:\"\";s:26:\"aiowps_db_backup_frequency\";s:1:\"4\";s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";s:1:\"2\";s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:18:\"kosadaka98@mail.ru\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:18:\"kosadaka98@mail.ru\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";}", "yes");
INSERT INTO `aw_options` VALUES("245", "cptch_options", "a:26:{s:21:\"plugin_option_version\";s:5:\"4.3.6\";s:7:\"str_key\";a:2:{s:4:\"time\";s:0:\"\";s:3:\"key\";s:0:\"\";}s:4:\"type\";s:12:\"math_actions\";s:12:\"math_actions\";a:3:{i:0;s:4:\"plus\";i:1;s:5:\"minus\";i:2;s:15:\"multiplications\";}s:14:\"operand_format\";a:3:{i:0;s:7:\"numbers\";i:1;s:5:\"words\";i:2;s:6:\"images\";}s:12:\"images_count\";i:5;s:5:\"title\";s:0:\"\";s:15:\"required_symbol\";s:1:\"*\";s:21:\"display_reload_button\";b:1;s:14:\"enlarge_images\";b:0;s:13:\"used_packages\";a:4:{i:0;i:2;i:1;i:4;i:2;i:6;i:3;i:7;}s:17:\"enable_time_limit\";b:0;s:10:\"time_limit\";i:120;s:9:\"no_answer\";s:49:\"Пожалуйста, заполните CAPTCHA.\";s:12:\"wrong_answer\";s:83:\"Пожалуйста, введите корректное значение CAPTCHA.\";s:14:\"time_limit_off\";s:118:\"Лимит Времени истёк. Пожалуйста, введите значение для CAPTCHA опять.\";s:21:\"time_limit_off_notice\";s:95:\"Лимит времени истёк. Пожалуйста, перезагрузите CAPTCHA.\";s:17:\"whitelist_message\";s:32:\"Вы в белом списке.\";s:13:\"load_via_ajax\";b:0;s:28:\"use_limit_attempts_whitelist\";b:0;s:23:\"display_settings_notice\";i:0;s:22:\"suggest_feature_banner\";i:1;s:5:\"forms\";a:5:{s:8:\"wp_login\";a:2:{s:6:\"enable\";b:1;s:20:\"hide_from_registered\";b:0;}s:11:\"wp_register\";a:2:{s:6:\"enable\";b:1;s:20:\"hide_from_registered\";b:0;}s:16:\"wp_lost_password\";a:2:{s:6:\"enable\";b:1;s:20:\"hide_from_registered\";b:0;}s:11:\"wp_comments\";a:2:{s:6:\"enable\";b:1;s:20:\"hide_from_registered\";b:1;}s:11:\"bws_contact\";a:2:{s:6:\"enable\";b:0;s:20:\"hide_from_registered\";b:0;}}s:17:\"plugin_db_version\";s:3:\"1.4\";s:13:\"first_install\";i:1511029866;s:19:\"go_settings_counter\";i:1;}", "yes");
INSERT INTO `aw_options` VALUES("246", "bstwbsftwppdtplgns_options", "a:1:{s:8:\"bws_menu\";a:1:{s:7:\"version\";a:1:{s:19:\"captcha/captcha.php\";s:5:\"2.0.6\";}}}", "yes");
INSERT INTO `aw_options` VALUES("253", "aiosp_home_description", "", "yes");
INSERT INTO `aw_options` VALUES("254", "aiosp_home_title", "", "yes");
INSERT INTO `aw_options` VALUES("255", "psp_canonical", "on", "yes");
INSERT INTO `aw_options` VALUES("256", "aiosp_home_keywords", "", "yes");
INSERT INTO `aw_options` VALUES("257", "aiosp_rewrite_titles", "on", "yes");
INSERT INTO `aw_options` VALUES("258", "aiosp_use_categories", "", "yes");
INSERT INTO `aw_options` VALUES("259", "psp_use_tags", "", "yes");
INSERT INTO `aw_options` VALUES("260", "psp_category_noindex", "on", "yes");
INSERT INTO `aw_options` VALUES("261", "psp_archive_noindex", "on", "yes");
INSERT INTO `aw_options` VALUES("262", "psp_tags_noindex", "on", "yes");
INSERT INTO `aw_options` VALUES("263", "psp_comnts_pages_noindex", "on", "yes");
INSERT INTO `aw_options` VALUES("264", "psp_comnts_feeds_noindex", "on", "yes");
INSERT INTO `aw_options` VALUES("265", "psp_rss_feeds_noindex", "on", "yes");
INSERT INTO `aw_options` VALUES("266", "psp_search_results_noindex", "on", "yes");
INSERT INTO `aw_options` VALUES("267", "psp_sub_pages_home_noindex", "on", "yes");
INSERT INTO `aw_options` VALUES("268", "psp_author_archives_noindex", "on", "yes");
INSERT INTO `aw_options` VALUES("269", "psp_noodp_metatag", "on", "yes");
INSERT INTO `aw_options` VALUES("270", "psp_noydir_metatag", "on", "yes");
INSERT INTO `aw_options` VALUES("271", "psp_nofollow_cat_pages", "", "yes");
INSERT INTO `aw_options` VALUES("272", "psp_nofollow_cat_posts", "", "yes");
INSERT INTO `aw_options` VALUES("273", "psp_nofollow_arc_pages", "", "yes");
INSERT INTO `aw_options` VALUES("274", "psp_nofollow_arc_posts", "", "yes");
INSERT INTO `aw_options` VALUES("275", "psp_nofollow_ext_links", "", "yes");
INSERT INTO `aw_options` VALUES("276", "psp_nofollow_login_reg", "on", "yes");
INSERT INTO `aw_options` VALUES("277", "psp_nofollow_tag_pages", "", "yes");
INSERT INTO `aw_options` VALUES("278", "psp_permalink_redirect", "on", "yes");
INSERT INTO `aw_options` VALUES("279", "aiosp_generate_descriptions", "on", "yes");
INSERT INTO `aw_options` VALUES("280", "aiosp_post_title_format", "%post_title% |", "yes");
INSERT INTO `aw_options` VALUES("281", "aiosp_page_title_format", "%page_title% |", "yes");
INSERT INTO `aw_options` VALUES("282", "aiosp_category_title_format", "%category_title% | %blog_title%", "yes");
INSERT INTO `aw_options` VALUES("283", "psp_taxonomy_title_format", "%term% | %blog_title%", "yes");
INSERT INTO `aw_options` VALUES("284", "aiosp_archive_title_format", "%date% | %blog_title%", "yes");
INSERT INTO `aw_options` VALUES("285", "aiosp_tag_title_format", "%tag% | %blog_title%", "yes");
INSERT INTO `aw_options` VALUES("286", "aiosp_search_title_format", "%search% | %blog_title%", "yes");
INSERT INTO `aw_options` VALUES("287", "aiosp_description_format", "%description%", "yes");
INSERT INTO `aw_options` VALUES("288", "aiosp_paged_format", " - Part %page%", "yes");
INSERT INTO `aw_options` VALUES("289", "aiosp_404_title_format", "Не найдено результатов для%request_words%", "yes");
INSERT INTO `aw_options` VALUES("290", "aiosp_post_meta_tags", "", "yes");
INSERT INTO `aw_options` VALUES("291", "aiosp_page_meta_tags", "", "yes");
INSERT INTO `aw_options` VALUES("292", "aiosp_home_meta_tags", "", "yes");
INSERT INTO `aw_options` VALUES("293", "aiosp_do_log", "", "yes");
INSERT INTO `aw_options` VALUES("294", "psp_link_home", "", "yes");
INSERT INTO `aw_options` VALUES("305", "category_children", "a:0:{}", "yes");
INSERT INTO `aw_options` VALUES("307", "_transient_all_the_cool_cats", "1", "yes");
INSERT INTO `aw_options` VALUES("312", "theme_switch_menu_locations", "a:0:{}", "yes");
INSERT INTO `aw_options` VALUES("313", "theme_switched_via_customizer", "", "yes");
INSERT INTO `aw_options` VALUES("314", "customize_stashed_theme_mods", "a:0:{}", "no");
INSERT INTO `aw_options` VALUES("331", "psp_max_words_excerpt", "", "yes");
INSERT INTO `aw_options` VALUES("332", "psp_debug_info", "", "yes");
INSERT INTO `aw_options` VALUES("339", "_transient_is_multi_author", "0", "yes");
INSERT INTO `aw_options` VALUES("340", "_transient_twentyfifteen_categories", "1", "yes");
INSERT INTO `aw_options` VALUES("354", "_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a", "1511087310", "no");
INSERT INTO `aw_options` VALUES("355", "_site_transient_poptags_40cd750bba9870f18aada2478b24840a", "O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4401;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2516;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:2401;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2379;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1842;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1613;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1608;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1439;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1363;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1362;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1349;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1281;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1274;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1157;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1067;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1055;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1002;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:967;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:835;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:833;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:817;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:782;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:773;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:679;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:674;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:670;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:661;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:659;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:648;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:642;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:636;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:617;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:612;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:599;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:591;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:588;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:587;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:583;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:568;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:568;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:550;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:540;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:529;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:525;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:513;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:504;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:503;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:493;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:483;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:479;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:479;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:474;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:458;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:456;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:454;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:448;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:447;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:444;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:425;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:416;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:415;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:414;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:409;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:408;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:407;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:399;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:392;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:389;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:385;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:374;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:358;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:350;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:346;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:344;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:336;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:335;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:334;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:331;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:331;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:330;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:326;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:325;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:325;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:322;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:314;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:305;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:302;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:301;}s:3:\"tag\";a:3:{s:4:\"name\";s:3:\"tag\";s:4:\"slug\";s:3:\"tag\";s:5:\"count\";i:298;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:297;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:296;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:289;}s:7:\"adsense\";a:3:{s:4:\"name\";s:7:\"adsense\";s:4:\"slug\";s:7:\"adsense\";s:5:\"count\";i:287;}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";i:287;}s:6:\"author\";a:3:{s:4:\"name\";s:6:\"author\";s:4:\"slug\";s:6:\"author\";s:5:\"count\";i:283;}s:8:\"lightbox\";a:3:{s:4:\"name\";s:8:\"lightbox\";s:4:\"slug\";s:8:\"lightbox\";s:5:\"count\";i:279;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:278;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:277;}s:7:\"tinymce\";a:3:{s:4:\"name\";s:7:\"tinyMCE\";s:4:\"slug\";s:7:\"tinymce\";s:5:\"count\";i:277;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:275;}}", "no");
INSERT INTO `aw_options` VALUES("357", "_site_transient_update_core", "O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:63:\"https://downloads.wordpress.org/release/ru_RU/wordpress-4.9.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:63:\"https://downloads.wordpress.org/release/ru_RU/wordpress-4.9.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:3:\"4.9\";s:7:\"version\";s:3:\"4.9\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1511076576;s:15:\"version_checked\";s:3:\"4.9\";s:12:\"translations\";a:0:{}}", "no");
INSERT INTO `aw_options` VALUES("358", "_site_transient_update_plugins", "O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1511076578;s:7:\"checked\";a:7:{s:19:\"akismet/akismet.php\";s:5:\"4.0.1\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.3.1\";s:19:\"captcha/captcha.php\";s:5:\"4.3.6\";s:25:\"duplicator/duplicator.php\";s:6:\"1.2.30\";s:9:\"hello.php\";s:3:\"1.6\";s:39:\"platinum-seo-pack/platinum_seo_pack.php\";s:5:\"1.3.8\";s:23:\"rustolat/rus-to-lat.php\";s:3:\"0.3\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:6:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.0.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.0.1.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:7:\"default\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";s:7:\"default\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.3.1\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";s:7:\"default\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1232826\";s:7:\"default\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1232826\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"captcha/captcha.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/captcha\";s:4:\"slug\";s:7:\"captcha\";s:6:\"plugin\";s:19:\"captcha/captcha.php\";s:11:\"new_version\";s:5:\"4.3.6\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/captcha/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/captcha.4.3.6.zip\";s:5:\"icons\";a:0:{}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:25:\"duplicator/duplicator.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:24:\"w.org/plugins/duplicator\";s:4:\"slug\";s:10:\"duplicator\";s:6:\"plugin\";s:25:\"duplicator/duplicator.php\";s:11:\"new_version\";s:6:\"1.2.30\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/duplicator/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/duplicator.1.2.30.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:63:\"https://ps.w.org/duplicator/assets/icon-128x128.png?rev=1298463\";s:2:\"2x\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=1298463\";s:7:\"default\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=1298463\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=1645055\";s:7:\"default\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=1645055\";}s:11:\"banners_rtl\";a:0:{}}s:39:\"platinum-seo-pack/platinum_seo_pack.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/platinum-seo-pack\";s:4:\"slug\";s:17:\"platinum-seo-pack\";s:6:\"plugin\";s:39:\"platinum-seo-pack/platinum_seo_pack.php\";s:11:\"new_version\";s:5:\"1.3.8\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/platinum-seo-pack/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/platinum-seo-pack.zip\";s:5:\"icons\";a:0:{}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:23:\"rustolat/rus-to-lat.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/rustolat\";s:4:\"slug\";s:8:\"rustolat\";s:6:\"plugin\";s:23:\"rustolat/rus-to-lat.php\";s:11:\"new_version\";s:3:\"0.3\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/rustolat/\";s:7:\"package\";s:55:\"https://downloads.wordpress.org/plugin/rustolat.0.3.zip\";s:5:\"icons\";a:0:{}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}}}", "no");
INSERT INTO `aw_options` VALUES("359", "_site_transient_update_themes", "O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1511076578;s:7:\"checked\";a:4:{s:9:\"semicolon\";s:5:\"0.9.1\";s:13:\"twentyfifteen\";s:3:\"1.9\";s:15:\"twentyseventeen\";s:3:\"1.4\";s:13:\"twentysixteen\";s:3:\"1.4\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}", "no");
INSERT INTO `aw_options` VALUES("360", "duplicator_settings", "a:10:{s:7:\"version\";s:6:\"1.2.30\";s:18:\"uninstall_settings\";b:1;s:15:\"uninstall_files\";b:1;s:16:\"uninstall_tables\";b:1;s:13:\"package_debug\";b:0;s:17:\"package_mysqldump\";b:1;s:22:\"package_mysqldump_path\";s:0:\"\";s:24:\"package_phpdump_qrylimit\";s:3:\"100\";s:17:\"package_zip_flush\";b:0;s:20:\"storage_htaccess_off\";b:0;}", "yes");
INSERT INTO `aw_options` VALUES("361", "duplicator_version_plugin", "1.2.30", "yes");
INSERT INTO `aw_options` VALUES("362", "duplicator_ui_view_state", "a:1:{s:24:\"dup-pack-installer-panel\";s:1:\"1\";}", "yes");
INSERT INTO `aw_options` VALUES("363", "duplicator_package_active", "O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2017-11-19 09:15:09\";s:7:\"Version\";s:6:\"1.2.30\";s:9:\"VersionWP\";s:3:\"4.9\";s:9:\"VersionDB\";s:6:\"5.6.37\";s:10:\"VersionPHP\";s:6:\"7.0.21\";s:9:\"VersionOS\";s:5:\"WINNT\";s:2:\"ID\";N;s:4:\"Name\";s:20:\"20171119_fotoprirody\";s:4:\"Hash\";s:32:\"78536bc7ae89d2de2923171119091509\";s:8:\"NameHash\";s:53:\"20171119_fotoprirody_78536bc7ae89d2de2923171119091509\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:40:\"C:/OSPanel/domains/test/wp-snapshots/tmp\";s:8:\"StoreURL\";s:25:\"http://test/wp-snapshots/\";s:8:\"ScanFile\";s:63:\"20171119_fotoprirody_78536bc7ae89d2de2923171119091509_scan.json\";s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";N;s:7:\"Archive\";O:11:\"DUP_Archive\":18:{s:10:\"FilterDirs\";s:0:\"\";s:11:\"FilterFiles\";s:0:\"\";s:10:\"FilterExts\";s:0:\"\";s:13:\"FilterDirsAll\";a:0:{}s:14:\"FilterFilesAll\";a:0:{}s:13:\"FilterExtsAll\";a:0:{}s:8:\"FilterOn\";i:0;s:12:\"ExportOnlyDB\";i:0;s:4:\"File\";N;s:6:\"Format\";s:3:\"ZIP\";s:7:\"PackDir\";s:23:\"C:/OSPanel/domains/test\";s:4:\"Size\";i:0;s:4:\"Dirs\";a:0:{}s:5:\"Files\";a:0:{}s:10:\"FilterInfo\";O:23:\"DUP_Archive_Filter_Info\":8:{s:4:\"Dirs\";O:34:\"DUP_Archive_Filter_Scope_Directory\":4:{s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:5:\"Files\";O:29:\"DUP_Archive_Filter_Scope_File\":5:{s:4:\"Size\";a:0:{}s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:4:\"Exts\";O:29:\"DUP_Archive_Filter_Scope_Base\":2:{s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:9:\"UDirCount\";i:0;s:10:\"UFileCount\";i:0;s:9:\"UExtCount\";i:0;s:8:\"TreeSize\";a:0:{}s:11:\"TreeWarning\";a:0:{}}s:10:\"\0*\0Package\";O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2017-11-19 09:15:09\";s:7:\"Version\";s:6:\"1.2.30\";s:9:\"VersionWP\";s:3:\"4.9\";s:9:\"VersionDB\";s:6:\"5.6.37\";s:10:\"VersionPHP\";s:6:\"7.0.21\";s:9:\"VersionOS\";s:5:\"WINNT\";s:2:\"ID\";N;s:4:\"Name\";s:20:\"20171119_fotoprirody\";s:4:\"Hash\";s:32:\"78536bc7ae89d2de2923171119091509\";s:8:\"NameHash\";s:53:\"20171119_fotoprirody_78536bc7ae89d2de2923171119091509\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:40:\"C:/OSPanel/domains/test/wp-snapshots/tmp\";s:8:\"StoreURL\";s:25:\"http://test/wp-snapshots/\";s:8:\"ScanFile\";N;s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";N;s:7:\"Archive\";r:22;s:9:\"Installer\";O:13:\"DUP_Installer\":7:{s:4:\"File\";N;s:4:\"Size\";i:0;s:10:\"OptsDBHost\";s:0:\"\";s:10:\"OptsDBPort\";s:0:\"\";s:10:\"OptsDBName\";s:0:\"\";s:10:\"OptsDBUser\";s:0:\"\";s:10:\"\0*\0Package\";r:57;}s:8:\"Database\";O:12:\"DUP_Database\":13:{s:4:\"Type\";s:5:\"MySQL\";s:4:\"Size\";N;s:4:\"File\";N;s:4:\"Path\";N;s:12:\"FilterTables\";s:0:\"\";s:8:\"FilterOn\";i:0;s:4:\"Name\";N;s:10:\"Compatible\";s:0:\"\";s:8:\"Comments\";s:28:\"MySQL Community Server (GPL)\";s:10:\"\0*\0Package\";r:57;s:25:\"\0DUP_Database\0dbStorePath\";N;s:23:\"\0DUP_Database\0EOFMarker\";s:0:\"\";s:26:\"\0DUP_Database\0networkFlush\";b:0;}}s:29:\"\0DUP_Archive\0tmpFilterDirsAll\";a:0:{}s:24:\"\0DUP_Archive\0wpCorePaths\";a:6:{i:0;s:32:\"C:/OSPanel/domains/test/wp-admin\";i:1;s:42:\"C:/OSPanel/domains/test/wp-content/uploads\";i:2;s:44:\"C:/OSPanel/domains/test/wp-content/languages\";i:3;s:42:\"C:/OSPanel/domains/test/wp-content/plugins\";i:4;s:41:\"C:/OSPanel/domains/test/wp-content/themes\";i:5;s:35:\"C:/OSPanel/domains/test/wp-includes\";}}s:9:\"Installer\";r:79;s:8:\"Database\";r:87;}", "yes");
INSERT INTO `aw_options` VALUES("366", "_transient_timeout_users_online", "1511084061", "no");
INSERT INTO `aw_options` VALUES("367", "_transient_users_online", "a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1511093061;s:10:\"ip_address\";s:9:\"127.0.0.1\";}}", "no");
INSERT INTO `aw_options` VALUES("369", "_site_transient_timeout_theme_roots", "1511084062", "no");
INSERT INTO `aw_options` VALUES("370", "_site_transient_theme_roots", "a:4:{s:9:\"semicolon\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}", "no");

/* INSERT TABLE DATA: aw_postmeta */
INSERT INTO `aw_postmeta` VALUES("1", "2", "_wp_page_template", "default");
INSERT INTO `aw_postmeta` VALUES("2", "1", "_edit_lock", "1511040922:1");
INSERT INTO `aw_postmeta` VALUES("3", "4", "_wp_attached_file", "2017/11/Men8BLnfaCY.jpg");
INSERT INTO `aw_postmeta` VALUES("4", "4", "_wp_attachment_metadata", "a:5:{s:5:\"width\";i:1080;s:6:\"height\";i:810;s:4:\"file\";s:23:\"2017/11/Men8BLnfaCY.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"Men8BLnfaCY-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"Men8BLnfaCY-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"Men8BLnfaCY-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:24:\"Men8BLnfaCY-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"Men8BLnfaCY-360x210.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:210;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"semicolon-mini\";a:4:{s:4:\"file\";s:21:\"Men8BLnfaCY-60x60.jpg\";s:5:\"width\";i:60;s:6:\"height\";i:60;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"semicolon-gallery\";a:4:{s:4:\"file\";s:23:\"Men8BLnfaCY-220x220.jpg\";s:5:\"width\";i:220;s:6:\"height\";i:220;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `aw_postmeta` VALUES("5", "4", "_wp_attachment_is_custom_background", "semicolon");
INSERT INTO `aw_postmeta` VALUES("6", "5", "_edit_lock", "1511033626:1");
INSERT INTO `aw_postmeta` VALUES("7", "6", "_wp_attached_file", "2017/11/AFgjjgUctkM.jpg");
INSERT INTO `aw_postmeta` VALUES("8", "6", "_wp_attachment_metadata", "a:5:{s:5:\"width\";i:607;s:6:\"height\";i:1080;s:4:\"file\";s:23:\"2017/11/AFgjjgUctkM.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"AFgjjgUctkM-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"AFgjjgUctkM-169x300.jpg\";s:5:\"width\";i:169;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:24:\"AFgjjgUctkM-576x1024.jpg\";s:5:\"width\";i:576;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"AFgjjgUctkM-360x210.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:210;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"semicolon-mini\";a:4:{s:4:\"file\";s:21:\"AFgjjgUctkM-60x60.jpg\";s:5:\"width\";i:60;s:6:\"height\";i:60;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"semicolon-gallery\";a:4:{s:4:\"file\";s:23:\"AFgjjgUctkM-220x220.jpg\";s:5:\"width\";i:220;s:6:\"height\";i:220;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `aw_postmeta` VALUES("9", "6", "_wp_attachment_is_custom_background", "semicolon");
INSERT INTO `aw_postmeta` VALUES("10", "5", "_wp_trash_meta_status", "publish");
INSERT INTO `aw_postmeta` VALUES("11", "5", "_wp_trash_meta_time", "1511033626");
INSERT INTO `aw_postmeta` VALUES("12", "7", "_wp_attached_file", "2017/11/tM-KxVS8ZUg.jpg");
INSERT INTO `aw_postmeta` VALUES("13", "7", "_wp_attachment_metadata", "a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:23:\"2017/11/tM-KxVS8ZUg.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"tM-KxVS8ZUg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"tM-KxVS8ZUg-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"tM-KxVS8ZUg-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:24:\"tM-KxVS8ZUg-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"tM-KxVS8ZUg-360x210.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:210;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"semicolon-mini\";a:4:{s:4:\"file\";s:21:\"tM-KxVS8ZUg-60x60.jpg\";s:5:\"width\";i:60;s:6:\"height\";i:60;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"semicolon-gallery\";a:4:{s:4:\"file\";s:23:\"tM-KxVS8ZUg-220x220.jpg\";s:5:\"width\";i:220;s:6:\"height\";i:220;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `aw_postmeta` VALUES("14", "7", "_wp_attachment_is_custom_background", "semicolon");
INSERT INTO `aw_postmeta` VALUES("15", "8", "_edit_lock", "1511033947:1");
INSERT INTO `aw_postmeta` VALUES("16", "8", "_wp_trash_meta_status", "publish");
INSERT INTO `aw_postmeta` VALUES("17", "8", "_wp_trash_meta_time", "1511033948");
INSERT INTO `aw_postmeta` VALUES("18", "9", "_wp_trash_meta_status", "publish");
INSERT INTO `aw_postmeta` VALUES("19", "9", "_wp_trash_meta_time", "1511034112");
INSERT INTO `aw_postmeta` VALUES("20", "10", "_edit_lock", "1511034348:1");
INSERT INTO `aw_postmeta` VALUES("21", "10", "_wp_trash_meta_status", "publish");
INSERT INTO `aw_postmeta` VALUES("22", "10", "_wp_trash_meta_time", "1511034348");
INSERT INTO `aw_postmeta` VALUES("23", "11", "_edit_lock", "1511034360:1");
INSERT INTO `aw_postmeta` VALUES("24", "11", "_wp_trash_meta_status", "publish");
INSERT INTO `aw_postmeta` VALUES("25", "11", "_wp_trash_meta_time", "1511034360");
INSERT INTO `aw_postmeta` VALUES("26", "12", "_edit_lock", "1511034583:1");
INSERT INTO `aw_postmeta` VALUES("27", "12", "_wp_trash_meta_status", "publish");
INSERT INTO `aw_postmeta` VALUES("28", "12", "_wp_trash_meta_time", "1511034583");
INSERT INTO `aw_postmeta` VALUES("29", "13", "_edit_lock", "1511035037:1");
INSERT INTO `aw_postmeta` VALUES("30", "14", "_wp_attached_file", "2017/11/GN6KUHBqlIg.jpg");
INSERT INTO `aw_postmeta` VALUES("31", "14", "_wp_attachment_metadata", "a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:949;s:4:\"file\";s:23:\"2017/11/GN6KUHBqlIg.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"GN6KUHBqlIg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"GN6KUHBqlIg-300x222.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:222;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"GN6KUHBqlIg-768x569.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:569;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:24:\"GN6KUHBqlIg-1024x759.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:759;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"GN6KUHBqlIg-360x210.jpg\";s:5:\"width\";i:360;s:6:\"height\";i:210;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"semicolon-mini\";a:4:{s:4:\"file\";s:21:\"GN6KUHBqlIg-60x60.jpg\";s:5:\"width\";i:60;s:6:\"height\";i:60;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"semicolon-gallery\";a:4:{s:4:\"file\";s:23:\"GN6KUHBqlIg-220x220.jpg\";s:5:\"width\";i:220;s:6:\"height\";i:220;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `aw_postmeta` VALUES("32", "14", "_wp_attachment_is_custom_background", "twentyfifteen");
INSERT INTO `aw_postmeta` VALUES("33", "13", "_wp_trash_meta_status", "publish");
INSERT INTO `aw_postmeta` VALUES("34", "13", "_wp_trash_meta_time", "1511035037");
INSERT INTO `aw_postmeta` VALUES("35", "15", "_edit_lock", "1511035804:1");
INSERT INTO `aw_postmeta` VALUES("36", "15", "_wp_trash_meta_status", "publish");
INSERT INTO `aw_postmeta` VALUES("37", "15", "_wp_trash_meta_time", "1511035804");
INSERT INTO `aw_postmeta` VALUES("38", "1", "_edit_last", "1");
INSERT INTO `aw_postmeta` VALUES("43", "1", "_wp_old_slug", "%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80");
INSERT INTO `aw_postmeta` VALUES("53", "1", "robotsmeta", "index,follow");
INSERT INTO `aw_postmeta` VALUES("54", "19", "_wp_trash_meta_status", "publish");
INSERT INTO `aw_postmeta` VALUES("55", "19", "_wp_trash_meta_time", "1511036625");
INSERT INTO `aw_postmeta` VALUES("56", "6", "_edit_lock", "1511041943:1");
INSERT INTO `aw_postmeta` VALUES("58", "21", "_wp_attached_file", "2017/11/cropped-AFgjjgUctkM.jpg");
INSERT INTO `aw_postmeta` VALUES("59", "21", "_wp_attachment_context", "custom-logo");
INSERT INTO `aw_postmeta` VALUES("60", "21", "_wp_attachment_metadata", "a:5:{s:5:\"width\";i:248;s:6:\"height\";i:247;s:4:\"file\";s:31:\"2017/11/cropped-AFgjjgUctkM.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"cropped-AFgjjgUctkM-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");

/* INSERT TABLE DATA: aw_posts */
INSERT INTO `aw_posts` VALUES("1", "1", "2017-11-16 12:37:22", "2017-11-16 09:37:23", "<img class=\"alignnone size-medium wp-image-4\" src=\"http://test/wp-content/uploads/2017/11/Men8BLnfaCY-300x225.jpg\" alt=\"\" width=\"300\" height=\"225\" />\r\n\r\n<strong><em>Добро пожаловать на мой блог!</em></strong>", "Фото природы", "", "publish", "open", "open", "", "foto_of_nature", "", "", "2017-11-18 23:22:48", "2017-11-18 20:22:48", "", "0", "http://test/?p=1", "0", "post", "", "0");
INSERT INTO `aw_posts` VALUES("2", "1", "2017-11-16 12:37:22", "2017-11-16 09:37:23", "Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:\n\n<blockquote>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</blockquote>\n\n...или так:\n\n<blockquote>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</blockquote>\n\nПерейдите <a href=\"http://test/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!", "Пример страницы", "", "publish", "closed", "open", "", "sample-page", "", "", "2017-11-16 12:37:22", "2017-11-16 09:37:23", "", "0", "http://test/?page_id=2", "0", "page", "", "0");
INSERT INTO `aw_posts` VALUES("3", "1", "2017-11-16 12:37:50", "0000-00-00 00:00:00", "", "Черновик", "", "auto-draft", "open", "open", "", "", "", "", "2017-11-16 12:37:50", "0000-00-00 00:00:00", "", "0", "http://test/?p=3", "0", "post", "", "0");
INSERT INTO `aw_posts` VALUES("4", "1", "2017-11-18 22:25:05", "2017-11-18 19:25:05", "", "Men8BLnfaCY", "", "inherit", "open", "closed", "", "men8blnfacy", "", "", "2017-11-18 23:14:14", "2017-11-18 20:14:14", "", "1", "http://test/wp-content/uploads/2017/11/Men8BLnfaCY.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `aw_posts` VALUES("5", "1", "2017-11-18 22:33:46", "2017-11-18 19:33:46", "{\n    \"semicolon::background_image\": {\n        \"value\": \"http://test/wp-content/uploads/2017/11/AFgjjgUctkM.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:33:15\"\n    },\n    \"semicolon::background_position_x\": {\n        \"value\": \"left\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:33:46\"\n    },\n    \"semicolon::background_position_y\": {\n        \"value\": \"center\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:33:46\"\n    }\n}", "", "", "trash", "closed", "closed", "", "6da2c2c4-7cfc-4720-8e89-cdff1a47e528", "", "", "2017-11-18 22:33:46", "2017-11-18 19:33:46", "", "0", "http://test/?p=5", "0", "customize_changeset", "", "0");
INSERT INTO `aw_posts` VALUES("6", "1", "2017-11-18 22:33:09", "2017-11-18 19:33:09", "", "AFgjjgUctkM", "", "inherit", "open", "closed", "", "afgjjguctkm", "", "", "2017-11-18 22:33:09", "2017-11-18 19:33:09", "", "0", "http://test/wp-content/uploads/2017/11/AFgjjgUctkM.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `aw_posts` VALUES("7", "1", "2017-11-18 22:36:45", "2017-11-18 19:36:45", "", "tM-KxVS8ZUg", "", "inherit", "open", "closed", "", "tm-kxvs8zug", "", "", "2017-11-18 22:36:45", "2017-11-18 19:36:45", "", "0", "http://test/wp-content/uploads/2017/11/tM-KxVS8ZUg.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `aw_posts` VALUES("8", "1", "2017-11-18 22:39:08", "2017-11-18 19:39:08", "{\n    \"semicolon::background_image\": {\n        \"value\": \"http://test/wp-content/uploads/2017/11/AFgjjgUctkM.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:37:49\"\n    },\n    \"semicolon::background_preset\": {\n        \"value\": \"repeat\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:37:49\"\n    },\n    \"semicolon::background_position_x\": {\n        \"value\": \"center\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:39:08\"\n    },\n    \"semicolon::background_position_y\": {\n        \"value\": \"bottom\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:39:08\"\n    },\n    \"semicolon::background_size\": {\n        \"value\": \"auto\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:37:49\"\n    },\n    \"semicolon::background_repeat\": {\n        \"value\": \"repeat\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:37:49\"\n    },\n    \"semicolon::background_attachment\": {\n        \"value\": \"scroll\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:37:49\"\n    }\n}", "", "", "trash", "closed", "closed", "", "5ad78aeb-9fb8-41a2-9185-c55d8b88d70c", "", "", "2017-11-18 22:39:08", "2017-11-18 19:39:08", "", "0", "http://test/?p=8", "0", "customize_changeset", "", "0");
INSERT INTO `aw_posts` VALUES("9", "1", "2017-11-18 22:41:52", "2017-11-18 19:41:52", "{\n    \"semicolon::background_image\": {\n        \"value\": \"http://test/wp-content/uploads/2017/11/Men8BLnfaCY.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:41:52\"\n    },\n    \"semicolon::background_preset\": {\n        \"value\": \"fill\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:41:52\"\n    },\n    \"semicolon::background_position_x\": {\n        \"value\": \"center\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:41:52\"\n    },\n    \"semicolon::background_position_y\": {\n        \"value\": \"center\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:41:52\"\n    },\n    \"semicolon::background_size\": {\n        \"value\": \"cover\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:41:52\"\n    },\n    \"semicolon::background_repeat\": {\n        \"value\": \"no-repeat\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:41:52\"\n    },\n    \"semicolon::background_attachment\": {\n        \"value\": \"fixed\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:41:52\"\n    }\n}", "", "", "trash", "closed", "closed", "", "ec3e5fae-a812-43cb-a124-1bc489075b40", "", "", "2017-11-18 22:41:52", "2017-11-18 19:41:52", "", "0", "http://test/2017/11/18/ec3e5fae-a812-43cb-a124-1bc489075b40/", "0", "customize_changeset", "", "0");
INSERT INTO `aw_posts` VALUES("10", "1", "2017-11-18 22:45:48", "2017-11-18 19:45:48", "{\n    \"semicolon::background_color\": {\n        \"value\": \"#ffffff\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:42:57\"\n    },\n    \"blogname\": {\n        \"value\": \"\\u0424\\u043e\\u0442\\u043e \\u043f\\u0440\\u0438\\u0440\\u043e\\u0434\\u044b\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:44:57\"\n    },\n    \"blogdescription\": {\n        \"value\": \"\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:45:48\"\n    }\n}", "", "", "trash", "closed", "closed", "", "b027237f-4c35-45bd-be59-3f75aa74e687", "", "", "2017-11-18 22:45:48", "2017-11-18 19:45:48", "", "0", "http://test/?p=10", "0", "customize_changeset", "", "0");
INSERT INTO `aw_posts` VALUES("11", "1", "2017-11-18 22:46:00", "2017-11-18 19:46:00", "{\n    \"semicolon::background_color\": {\n        \"value\": \"#191919\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:45:58\"\n    }\n}", "", "", "trash", "closed", "closed", "", "2c981376-d68b-4310-bab0-72e54a1649fa", "", "", "2017-11-18 22:46:00", "2017-11-18 19:46:00", "", "0", "http://test/?p=11", "0", "customize_changeset", "", "0");
INSERT INTO `aw_posts` VALUES("12", "1", "2017-11-18 22:49:43", "2017-11-18 19:49:43", "{\n    \"widget_categories[2]\": {\n        \"value\": {\n            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjE0OiLQoNGD0LHRgNC40LrQuCI7czo1OiJjb3VudCI7aTowO3M6MTI6ImhpZXJhcmNoaWNhbCI7aTowO3M6ODoiZHJvcGRvd24iO2k6MDt9\",\n            \"title\": \"\\u0420\\u0443\\u0431\\u0440\\u0438\\u043a\\u0438\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"beb6356a7dc7bab865f11d891147c705\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:47:58\"\n    }\n}", "", "", "trash", "closed", "closed", "", "29073e9e-76f5-4db4-9f2b-dae7c4902d08", "", "", "2017-11-18 22:49:43", "2017-11-18 19:49:43", "", "0", "http://test/?p=12", "0", "customize_changeset", "", "0");
INSERT INTO `aw_posts` VALUES("13", "1", "2017-11-18 22:57:17", "2017-11-18 19:57:17", "{\n    \"semicolon::background_preset\": {\n        \"value\": \"fill\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:51:58\"\n    },\n    \"semicolon::background_position_x\": {\n        \"value\": \"center\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:56:28\"\n    },\n    \"semicolon::background_position_y\": {\n        \"value\": \"top\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:57:17\"\n    },\n    \"semicolon::background_size\": {\n        \"value\": \"cover\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:51:58\"\n    },\n    \"semicolon::background_image\": {\n        \"value\": \"http://test/wp-content/uploads/2017/11/GN6KUHBqlIg.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 19:57:17\"\n    }\n}", "", "", "trash", "closed", "closed", "", "188ad2d1-c145-46e6-aa7d-cff45d38982b", "", "", "2017-11-18 22:57:17", "2017-11-18 19:57:17", "", "0", "http://test/?p=13", "0", "customize_changeset", "", "0");
INSERT INTO `aw_posts` VALUES("14", "1", "2017-11-18 22:56:44", "2017-11-18 19:56:44", "", "GN6KUHBqlIg", "", "inherit", "open", "closed", "", "gn6kuhbqlig", "", "", "2017-11-18 22:56:44", "2017-11-18 19:56:44", "", "0", "http://test/wp-content/uploads/2017/11/GN6KUHBqlIg.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `aw_posts` VALUES("15", "1", "2017-11-18 23:10:04", "2017-11-18 20:10:04", "{\n    \"old_sidebars_widgets_data\": {\n        \"value\": {\n            \"wp_inactive_widgets\": [],\n            \"sidebar-1\": [\n                \"search-2\",\n                \"recent-posts-2\",\n                \"recent-comments-2\",\n                \"archives-2\",\n                \"categories-2\",\n                \"meta-2\"\n            ],\n            \"sidebar-2\": [],\n            \"sidebar-3\": [],\n            \"footer-sidebar\": []\n        },\n        \"type\": \"global_variable\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 20:08:24\"\n    },\n    \"twentyfifteen::background_color\": {\n        \"value\": \"#000000\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 20:08:24\"\n    },\n    \"twentyfifteen::background_image\": {\n        \"value\": \"http://test/wp-content/uploads/2017/11/GN6KUHBqlIg.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 20:08:24\"\n    },\n    \"twentyfifteen::sidebar_textcolor\": {\n        \"value\": \"#2a892f\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 20:08:24\"\n    },\n    \"twentyfifteen::header_background_color\": {\n        \"value\": \"#141004\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 20:09:24\"\n    },\n    \"twentyfifteen::background_position_x\": {\n        \"value\": \"left\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 20:09:24\"\n    },\n    \"twentyfifteen::background_position_y\": {\n        \"value\": \"top\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 20:09:24\"\n    }\n}", "", "", "trash", "closed", "closed", "", "f356d624-fe7b-4881-81fa-8050d6d734b5", "", "", "2017-11-18 23:10:04", "2017-11-18 20:10:04", "", "0", "http://test/?p=15", "0", "customize_changeset", "", "0");
INSERT INTO `aw_posts` VALUES("16", "1", "2017-11-19 00:09:35", "2017-11-18 21:09:35", "<img class=\"alignnone size-medium wp-image-4\" src=\"http://test/wp-content/uploads/2017/11/Men8BLnfaCY-300x225.jpg\" alt=\"\" width=\"300\" height=\"225\" />\n<span style=\"display: inline-block; width: 0px; overflow-x: hidden; overflow-y: hidden; line-height: 0;\" data-mce-type=\"bookmark\" class=\"mce_SELRES_start\">﻿</span>\n<strong><em>Добро пожаловать на мой блог!</em></strong>", "Фото природы", "", "inherit", "closed", "closed", "", "1-autosave-v1", "", "", "2017-11-19 00:09:35", "2017-11-18 21:09:35", "", "1", "http://test/2017/11/18/1-autosave-v1/", "0", "revision", "", "0");
INSERT INTO `aw_posts` VALUES("17", "1", "2017-11-18 23:16:10", "2017-11-18 20:16:10", "<img class=\"alignnone size-medium wp-image-4\" src=\"http://test/wp-content/uploads/2017/11/Men8BLnfaCY-300x225.jpg\" alt=\"\" width=\"300\" height=\"225\" />Добро пожаловать на мой блог!", "Фото природы", "", "inherit", "closed", "closed", "", "1-revision-v1", "", "", "2017-11-18 23:16:10", "2017-11-18 20:16:10", "", "1", "http://test/2017/11/18/1-revision-v1/", "0", "revision", "", "0");
INSERT INTO `aw_posts` VALUES("18", "1", "2017-11-18 23:22:48", "2017-11-18 20:22:48", "<img class=\"alignnone size-medium wp-image-4\" src=\"http://test/wp-content/uploads/2017/11/Men8BLnfaCY-300x225.jpg\" alt=\"\" width=\"300\" height=\"225\" />\r\n\r\n<strong><em>Добро пожаловать на мой блог!</em></strong>", "Фото природы", "", "inherit", "closed", "closed", "", "1-revision-v1", "", "", "2017-11-18 23:22:48", "2017-11-18 20:22:48", "", "1", "http://test/2017/11/18/1-revision-v1/", "0", "revision", "", "0");
INSERT INTO `aw_posts` VALUES("19", "1", "2017-11-18 23:23:45", "2017-11-18 20:23:45", "{\n    \"widget_recent-comments[2]\": {\n        \"value\": {\n            \"encoded_serialized_instance\": \"YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo2OiJudW1iZXIiO2k6Mzt9\",\n            \"title\": \"\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"c564fc664c703f46c05201391120f70c\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 20:23:45\"\n    }\n}", "", "", "trash", "closed", "closed", "", "e3cd73ab-03c4-4faf-baf3-0876f3d5e8e2", "", "", "2017-11-18 23:23:45", "2017-11-18 20:23:45", "", "0", "http://test/2017/11/18/e3cd73ab-03c4-4faf-baf3-0876f3d5e8e2/", "0", "customize_changeset", "", "0");
INSERT INTO `aw_posts` VALUES("20", "1", "2017-11-19 00:16:30", "0000-00-00 00:00:00", "{\n    \"blogdescription\": {\n        \"value\": \"\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 21:14:30\"\n    },\n    \"twentyfifteen::header_textcolor\": {\n        \"value\": \"#333333\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 21:14:30\"\n    },\n    \"twentyfifteen::custom_logo\": {\n        \"value\": \"\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2017-11-18 21:16:30\"\n    }\n}", "", "", "auto-draft", "closed", "closed", "", "e52a3581-296a-4578-b9cd-23dfc1f421b4", "", "", "2017-11-19 00:16:30", "2017-11-18 21:16:30", "", "0", "http://test/?p=20", "0", "customize_changeset", "", "0");
INSERT INTO `aw_posts` VALUES("21", "1", "2017-11-19 00:15:23", "2017-11-18 21:15:23", "http://test/wp-content/uploads/2017/11/cropped-AFgjjgUctkM.jpg", "cropped-AFgjjgUctkM.jpg", "", "inherit", "open", "closed", "", "cropped-afgjjguctkm-jpg", "", "", "2017-11-19 00:15:23", "2017-11-18 21:15:23", "", "0", "http://test/wp-content/uploads/2017/11/cropped-AFgjjgUctkM.jpg", "0", "attachment", "image/jpeg", "0");

/* INSERT TABLE DATA: aw_term_relationships */
INSERT INTO `aw_term_relationships` VALUES("1", "1", "0");
INSERT INTO `aw_term_relationships` VALUES("1", "2", "0");

/* INSERT TABLE DATA: aw_term_taxonomy */
INSERT INTO `aw_term_taxonomy` VALUES("1", "1", "category", "", "0", "1");
INSERT INTO `aw_term_taxonomy` VALUES("2", "2", "post_format", "", "0", "1");

/* INSERT TABLE DATA: aw_terms */
INSERT INTO `aw_terms` VALUES("1", "Без рубрики", "%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8", "0");
INSERT INTO `aw_terms` VALUES("2", "post-format-image", "post-format-image", "0");

/* INSERT TABLE DATA: aw_usermeta */
INSERT INTO `aw_usermeta` VALUES("1", "1", "nickname", "Admin");
INSERT INTO `aw_usermeta` VALUES("2", "1", "first_name", "");
INSERT INTO `aw_usermeta` VALUES("3", "1", "last_name", "");
INSERT INTO `aw_usermeta` VALUES("4", "1", "description", "");
INSERT INTO `aw_usermeta` VALUES("5", "1", "rich_editing", "true");
INSERT INTO `aw_usermeta` VALUES("6", "1", "comment_shortcuts", "false");
INSERT INTO `aw_usermeta` VALUES("7", "1", "admin_color", "fresh");
INSERT INTO `aw_usermeta` VALUES("8", "1", "use_ssl", "0");
INSERT INTO `aw_usermeta` VALUES("9", "1", "show_admin_bar_front", "true");
INSERT INTO `aw_usermeta` VALUES("10", "1", "locale", "");
INSERT INTO `aw_usermeta` VALUES("11", "1", "aw_capabilities", "a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `aw_usermeta` VALUES("12", "1", "aw_user_level", "10");
INSERT INTO `aw_usermeta` VALUES("13", "1", "dismissed_wp_pointers", "theme_editor_notice,bws_shortcode_button_tooltip");
INSERT INTO `aw_usermeta` VALUES("14", "1", "show_welcome_panel", "1");
INSERT INTO `aw_usermeta` VALUES("15", "1", "session_tokens", "a:1:{s:64:\"38d9fab231c06f2204278a6960bb9362fb3ea396aaf6f0779a831267c1ea16bb\";a:4:{s:10:\"expiration\";i:1512034667;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:64:\"Opera/9.80 (Windows NT 6.2; WOW64) Presto/2.12.388 Version/12.11\";s:5:\"login\";i:1510825067;}}");
INSERT INTO `aw_usermeta` VALUES("16", "1", "aw_dashboard_quick_press_last_post_id", "3");
INSERT INTO `aw_usermeta` VALUES("17", "1", "community-events-location", "a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}");
INSERT INTO `aw_usermeta` VALUES("18", "1", "closedpostboxes_dashboard", "a:0:{}");
INSERT INTO `aw_usermeta` VALUES("19", "1", "metaboxhidden_dashboard", "a:1:{i:0;s:21:\"dashboard_browser_nag\";}");
INSERT INTO `aw_usermeta` VALUES("20", "1", "aw_user-settings", "libraryContent=browse&editor=tinymce&post_dfw=off");
INSERT INTO `aw_usermeta` VALUES("21", "1", "aw_user-settings-time", "1511076489");
INSERT INTO `aw_usermeta` VALUES("22", "1", "closedpostboxes_post", "a:0:{}");
INSERT INTO `aw_usermeta` VALUES("23", "1", "metaboxhidden_post", "a:8:{i:0;s:12:\"revisionsdiv\";i:1;s:11:\"postexcerpt\";i:2;s:13:\"trackbacksdiv\";i:3;s:10:\"postcustom\";i:4;s:16:\"commentstatusdiv\";i:5;s:11:\"commentsdiv\";i:6;s:7:\"slugdiv\";i:7;s:9:\"authordiv\";}");

/* INSERT TABLE DATA: aw_users */
INSERT INTO `aw_users` VALUES("1", "Admin", "$P$BLLU.eL2ls.L/ev8B.jP2Mw1KmLJ8Q0", "admin", "kosadaka98@mail.ru", "", "2017-11-16 09:37:22", "", "0", "Admin");

SET FOREIGN_KEY_CHECKS = 1; 

/* Duplicator WordPress Timestamp: 2017-11-19 09:15:24*/
/* DUPLICATOR_MYSQLDUMP_EOF */
